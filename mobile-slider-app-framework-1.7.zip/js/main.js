jQuery(document).ready(function($){
    // jQuery functions and actions
});
